//
//  emotionViewController.swift
//  SeSAC-Assignment-4
//
//  Created by Jaka on 2024-05-20.
//

import UIKit

class emotionViewController: UIViewController {

    
    @IBOutlet var image1: UIButton!
    @IBOutlet var image2: UIButton!
    @IBOutlet var image3: UIButton!
    @IBOutlet var image4: UIButton!
    @IBOutlet var image5: UIButton!
    @IBOutlet var image6: UIButton!
    @IBOutlet var image7: UIButton!
    @IBOutlet var image8: UIButton!
    @IBOutlet var image9: UIButton!
    
    @IBOutlet var label1: UILabel!
    @IBOutlet var label2: UILabel!
    @IBOutlet var label3: UILabel!
    @IBOutlet var label4: UILabel!
    @IBOutlet var label5: UILabel!
    @IBOutlet var label6: UILabel!
    @IBOutlet var label7: UILabel!
    @IBOutlet var label8: UILabel!
    @IBOutlet var label9: UILabel!
    
    var l1 = 0
    var l2 = 0
    var l3 = 0
    var l4 = 0
    var l5 = 0
    var l6 = 0
    var l7 = 0
    var l8 = 0
    var l9 = 0
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        image1.setTitle("", for: .normal)
        image2.setTitle("", for: .normal)
        image3.setTitle("", for: .normal)
        image4.setTitle("", for: .normal)
        image5.setTitle("", for: .normal)
        image6.setTitle("", for: .normal)
        image7.setTitle("", for: .normal)
        image8.setTitle("", for: .normal)
        image9.setTitle("", for: .normal)
        
        
        label1.textAlignment = .center
        label1.text = "행복해"
        label1.textColor = .white
        label2.textAlignment = .center
        label2.text = "사랑해"
        label2.textColor = .white
        label3.textAlignment = .center
        label3.text = "좋아해"
        label3.textColor = .white
        label4.textAlignment = .center
        label4.text = "당황해"
        label4.textColor = .white
        label5.textAlignment = .center
        label5.text = "속상해"
        label5.textColor = .white
        label6.textAlignment = .center
        label6.text = "우울해"
        label6.textColor = .white
        label7.textAlignment = .center
        label7.text = "심심해"
        label7.textColor = .white
        label8.textAlignment = .center
        label8.text = "불안해"
        label8.textColor = .white
        label9.textAlignment = .center
        label9.text = "슬퍼해"
        label9.textColor = .white
    }
    
    
    @IBAction func Image1clicked(_ sender: UIButton) {
        l1 += 1
        label1.text = "행복해 \(l1)"
    }
    
    @IBAction func Image2clicked(_ sender: UIButton) {
        l2 += 1
        label2.text = "사랑해 \(l2)"
    }
    @IBAction func Image3clicked(_ sender: UIButton) {
        l3 += 1
        label3.text = "좋아해 \(l3)"
    }
    @IBAction func Image4clicked(_ sender: UIButton) {
        l4 += 1
        label4.text = "당황해 \(l4)"
    }
    @IBAction func Image5clicked(_ sender: UIButton) {
        l5 += 1
        label5.text = "속상해 \(l5)"
    }
    @IBAction func Image6clicked(_ sender: UIButton) {
        l6 += 1
        label6.text = "우울해 \(l6)"
    }
    @IBAction func Image7clicked(_ sender: UIButton) {
        l7 += 1
        label7.text = "심심해 \(l7)"
    }
    @IBAction func Image8clicked(_ sender: UIButton) {
        l8 += 1
        label8.text = "물안해 \(l8)"
    }
    @IBAction func Image9clicked(_ sender: UIButton) {
        l9 += 1
        label9.text = "슬퍼해 \(l9)"
    }
}
